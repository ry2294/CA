VectorXf v;
v.setRandom(3);
cout << v << endl;
